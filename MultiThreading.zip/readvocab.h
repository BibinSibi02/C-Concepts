/* BIBIN SIBI
 * CS480
 * RED ID:825763777 */

#ifndef PA2_SIBIB_READVOCAB_H
#define PA2_SIBIB_READVOCAB_H


void * readvocab(void * data);


#endif //PA2_SIBIB_READVOCAB_H
