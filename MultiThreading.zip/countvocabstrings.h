/* BIBIN SIBI
 * CS480
 * RED ID:825763777 */

#ifndef PA2_SIBIB_COUNTVOCABSTRINGS_H
#define PA2_SIBIB_COUNTVOCABSTRINGS_H


void * countvocabstrings(void * data);


#endif //PA2_SIBIB_COUNTVOCABSTRINGS_H
