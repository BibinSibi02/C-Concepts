/* BIBIN SIBI
 * CS480
 * RED ID:825763777 */

#ifndef PA2_SIBIB_READLINES_H
#define PA2_SIBIB_READLINES_H


void * readlines(void * data);


#endif //PA2_SIBIB_READLINES_H
